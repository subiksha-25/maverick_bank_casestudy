package com.example.maverickbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaverickbankFApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaverickbankFApplication.class, args);
	}

}
